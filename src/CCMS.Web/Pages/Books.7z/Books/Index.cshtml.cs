﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CCMS.Web.Pages.Books;

public class IndexModel : PageModel
{
    public void OnGet()
    {

    }
}